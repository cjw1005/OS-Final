make image
bochs -f bochsrc
