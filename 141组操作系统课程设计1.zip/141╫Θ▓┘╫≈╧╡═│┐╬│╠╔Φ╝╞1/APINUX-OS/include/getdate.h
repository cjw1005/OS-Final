#include "stdio.h"
#include "math.h"

int a=2021;
int b=12;
int c=1;
int z=0;

PUBLIC void countdate(int fd_stdin, int fd_stdout) {
    // Specify the rules of the game
        clear();
        printf("enter a date and we will tell you what day of the year it is!\n");
	printf("please enter the year\n");
        read(fd_stdin, a, 4);
	//read(fd_stdin,a,4);
	//printf("you enterd %d\n",a);
	printf("please enter the month\n");
	read(fd_stdin,b,2);
	//printf("you enterd %d\n",b);
	printf("please enter the day\n");
	read(fd_stdin,c,2);
	//printf("you enterd %d\n",c);
	if (a % 4 == 0 && a % 100 != 0)
		switch (b)
		{
		case 1:
			if (c <= 31)
			{
				z = c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 2:
			if (c <= 29)
			{
				z = 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 3:
			if (c <= 31)
			{
				z = 31 + 29 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 4:
			if (c <= 30)
			{
				z = 31 + 29 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 5:
			if (c <= 31)
			{
				z = 31 + 29 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 6:
			if (c <= 30)
			{
				z = 31 + 29 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 7:
			if (c <= 31)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 8:
			if (c <= 31)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 9:
			if (c <= 30)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 10:
			if (c <= 31)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 11:
			if (c <= 30)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 12:
			if (c <= 31)
			{
				z = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		default:
			printf("wrong input\n"); break;
		}
	else
		switch (b)
		{
		case 1:
			if (c <= 31)
			{
				z = c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 2:
			if (c <= 28)
			{
				z = 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 3:
			if (c <= 31)
			{
				z = 31 + 28 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 4:
			if (c <= 30)
			{
				z = 31 + 28 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 5:
			if (c <= 31)
			{
				z = 31 + 28 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 6:
			if (c <= 30)
			{
				z = 31 + 28 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 7:
			if (c <= 31)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 8:
			if (c <= 31)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 9:
			if (c <= 30)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 10:
			if (c <= 31)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 11:
			if (c <= 30)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		case 12:
			if (c <= 31)
			{
				z = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + c;
				printf("%d-%d-%dis the %dday of year%d\n", a, b, c,z,a);
				break;
			}
			else
				printf("wrong input\n"); break;
		default:
			printf("wrong input\n"); break;
		}
	return 0;
}
