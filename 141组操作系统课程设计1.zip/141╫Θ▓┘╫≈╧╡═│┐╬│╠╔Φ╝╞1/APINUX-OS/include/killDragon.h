#include <stdio.h>;
void state(int hp, int hp2, int mp, int mp2, int atk) {
	printf("Your attributu��HP��%d/%d��MP%d/%d��Damage %d", hp2, hp, mp2, mp, atk);
};

int killDragon(int fd_stdin, int fd_stdout)
{
	char wait[3] = { '0' };
	read(fd_stdin, wait, 2);


	//printf("   ===============================================================\n");
	//printf("   =                                                             =\n");
	//printf("   =                                                             =\n");
	printf(" HERO KILL DRAGON \n\n");
	printf(" PRESS ENTER TO CONTINUE\n");
	//printf("   =                                      APINUX���ϳ�Ʒ         =\n");
	//printf("   =                                                             =\n");
	//printf("   ===============================================================\n\n\n\n");
	read(fd_stdin, wait, 2);

	printf("plot introduction:\n Once upon a time, there was a beautiful kingdom where people lived and worked in peace and contentment, politics were clean and economy was prosperous. \n");

	printf(" Until one day, a dragon came to the wild west of the capital, built a castle by magic, \n and sent his general, the Lord of Fear, to capture the princess and imprison her in the dungeon of the castle. \n");
	read(fd_stdin, wait, 2);
	printf(" PRESS ENTER TO CONTINUE\n");
	printf(" The king was so worried that he sent out a call to the whole nation, who could kill the devil and save the princess, \n to marry the princess to him, and inherit the throne in the future! \n");

	printf(" But a thousand warriors went to the castle, and they all went away... \n");
	read(fd_stdin, wait, 2);
	printf(" PRESS ENTER TO CONTINUE\n");
	printf(" Finally, there you are! You are the most powerful warrior in the land, and you believe you can defeat the Devil and save the princess. \n");

	printf(" Now, you are ready to make some preparations in the capital, polishing weapons, getting supplies, heading to the castle... \n\n\n");



	int hp = 500, mp = 100, atk = 50, skill = 100;/*�������ǵ�����ֵ��ħ��ֵ�����������������ܹ�����*/
	int hp2 = hp, mp2 = mp; int gold = 500;/*�������ǵĵ�ǰ����ֵ��ħ��ֵ*/
	int a = 0, b = 0, c = 0;/*���弸���β�*/
	char buf[5] = { 0 };
	read(fd_stdin, buf, 2);
	c = buf[0] - '0';
	do {
		printf("You are in the capital of the kingdom. \n Your current state is \n");
		state(hp, hp2, mp, mp2, atk);
		printf(" You now have %d gold pieces. \n You can now go to :\n", gold);
		printf("1.Dragon castle 2.Weapon shop 3. Hotel 4. Martial Arts School 9.exit\n");
		read(fd_stdin, buf, 2);
		c = buf[0] - '0';
		if (c == 9) {
			return 0;
		}
		switch (c) {
		case 1: /*�����Ǳ�*/ {
			printf("Are you sure? To the dragon Castle is about to face a battle...\nYes!!!��1//  No//0\n");
			read(fd_stdin, buf, 2);
			a = buf[0] - '0';
			if (a != 1)
				c = 5;
			break;
		};
		case 2:/*������*/ {
			printf("You come to the weapon shop.\n");
			printf("Owner��Welcom��What can I help you��");
			printf("1.Iron sword-200g 2.Silver sword-300g 3.Golden shield-200g 4.Holly shield-500g\n");
			read(fd_stdin, buf, 2);
			b = buf[0] - '0';
			switch (b)
			{
			case 1:/*����*/ {
				if (gold < 200) {
					printf("Lack of money��");

				}
				else
				{
					printf("You have iron sword��atk+20��");
					gold -= 200; atk += 20;
				}
				break;
				; }
			case 2:/*����*/ {
				if (gold < 300) {
					printf("Lack of money��");

				}
				else
				{
					printf("You have silver sword��atk+40��");
					gold -= 300; atk += 40;
				}
				break;
			};
			case 3:/*���*/ {
				if (gold < 300) {
					printf("Lack of money��");

				}
				else
				{
					printf("You have golden shield,hp+300��");
					gold -= 300; hp += 300; hp2 += 300;
				}
				break;
			}
			case 4:/*ʥ��*/ {
				if (gold < 500) {
					printf("Lack of money��");

				}
				else
				{
					printf("You have golden shield,hp+300��skill+100��");
					gold -= 500; hp += 500; hp2 += 500; skill += 100;
				};
				break;
			}
			}
			break;
		};
		case 3:/*�õ�*/ {
			printf("There were not many people in the hotel, and the hospitable lady asked what you were coming for:\n");
			printf("1. I'm staying overnight. A single room, please. -50$\n2. I'm going to save the princess and find a partner. \n");
			read(fd_stdin, buf, 2);
			b = buf[0] - '0';
			if (b == 1) {
				gold = gold - 70;
				printf("The landlady gave you a key to an upstairs room, and you went to sleep with satisfaction.\n");
				printf("You wake up the next day and are surprised to find that your purse has been stolen.-20$");

			}
			else if (b == 2) {
				while (1) {
					printf("Madame secretly tells you that there are some good players in the hotel, \n1. Paladin - 50Gg 2. Berserker -100g 3. Mage -50g 4. Leave\n");
					printf("What do you want��");
					read(fd_stdin, buf, 2);
					b = buf[0] - '0';
					if (b == 1) {
						if (gold < 50) {
							printf("Lack of money��");

						}
						else
						{
							printf("Cross Chopper base damage has been increased!");
							gold -= 50; skill += 50;
						}
					}
					else if (b == 2) {
						if (gold < 100) {
							printf("Lack of money��");

						}
						else
						{
							printf("Base damage has been increased!");
							gold -= 100; atk += 7;
						}
					}
					else if (b == 3) {
						if (gold < 50) {
							printf("Lack of money!");

						}
						else
						{
							printf("Mana has gone up!");
							gold -= 50; mp += 50; mp2 = 50;
						}
					}
					else if (b == 4) {
						break;
					}
					else {
						printf("Madame could not understand what you were saying, and smiled politely.");
					}
				}

			}

			break;
		};
		case 4:/*�����*/ {
			printf(" The master of this martial arts school is very good. Practicing with him can improve your fighting ability, but you will inevitably get some injuries.");
			printf(" Do you want to practice with Master Shifu? 1. Want to! 2. Forget it. \n");
			read(fd_stdin, buf, 2);
			b = buf[0] - '0';
			switch (b) {
			case 1: {
				hp = hp - 50;
				atk = atk + 100;
				skill = skill + 100;
				if (hp <= 0) {
					printf("You were beaten to death by an old master.\n");
				}
				else
				{
					printf(" Base attack and skill damage increased! Base attack +100 skill attack +100\n");
					printf(" but hurt. hp-50\n");
				};
				break;
			}
			case 2: {
				printf("You leaved��\n");
				break;
			}

			default: {printf("Wrong Input��"); break; }

			};
		}
		};
		printf("\n\n\n");
	} while (c != 1 && hp > 0);/*�׶��¼���*/
	if (hp > 0) {
		printf("You came to the dragon Castle. You saw the dragon! You drew your longsword and began to fight the dragon!");
		int hp3 = 1000, atk3 = 50;/*�������Ѫ����������*/
		printf("\nDrangon's hp=1000!\n");
		do/*�����׶�*/
		{
			printf("It's your turn to act! \n1. Normal attack 2. Cross cut 3. Rest 4. Judge the situation 9.exit");
			//scanf_s("%d", &b);
			read(fd_stdin, buf, 2);
			b = buf[0] - '0';
			if (b == 9) {
				return 0;
			}
			switch (b) {
			case 1: {hp3 -= atk;
				printf("You slashed at the dragon! Dragon takes % D damage! The dragon has % D health!\n", atk, hp3);

				break;
			};
			case 2: {hp3 -= skill;
				printf("You slashed at the dragon with the cross! Dragon takes % D damage! The dragon has % D health!\n", skill, hp3);

				break;
			};
			case 3: {
				printf("You start resting and regenerating. You regain 20 HP and 20 MP!\n");
				hp2 += 20; mp2 += 20;
				if (hp2 > hp)
				{
					hp2 = hp;
				};
				if (mp2 > mp)
				{
					mp2 = mp;
				};/*��ֹ��ֵ���*/
				break;
			}
			case 4:state(hp, hp2, mp, mp2, atk); printf("\nThe dragon also has % D health", hp3);
			};
			hp2 -= 50;
			printf("It's the dragon's turn! The dragon deals 50 damage to you! You have % D of health left!", hp2);
			if (hp2 <= 0) {
				printf("\n\n Your blood is at zero! You were defeated by the dragon!");
				return 0;


			};

		} while (hp3 > 0);
		printf("\n The dragon's health is zero! \n You beat the dragon! Save the princess! And live happily ever after! . \n");

	}


	return 0;
};