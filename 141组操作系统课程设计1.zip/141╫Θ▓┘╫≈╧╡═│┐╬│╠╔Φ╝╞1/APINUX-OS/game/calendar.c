
#include "type.h"
#include "stdio.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "proto.h"


int Zeller(int a1, int m, int d)
{
	int w, c, y;
	c = (a1 - a1 % 100) / 100;
	y = a1 % 100;
	if (m > 2)
		;
	else {
		m += 12;
		a1 = a1 - 1;
		c = (a1 - a1 % 100) / 100;
		y = a1 % 100;

	}
	w = y + y / 4 + c / 4 - 2 * c + 13 * (m + 1) / 5 + d - 1;

	while (w < 0) {
		w = w + 7;
	}


	return w % 7;
}
void userInput(int fd_stdin,int fd_stdout)
{

    int n;
    int pos = 0,x,y;
    char inputCmd[80]={0};
L1: printf("Please Input The Year. ex:2012\n");
    read(fd_stdin,inputCmd,80);
    inputCmd[4] = 0;
    atoi(inputCmd,&x);
    printf("Please Input The Month. ex:7\n");
    read(fd_stdin,inputCmd,80);
    for(;pos<80;pos++)
    {
    	if(inputCmd[pos] == '0')
    		break;
    	if(pos>2){
    		pos = 2;
    		break;
    	}
    }
    inputCmd[pos] = 0;
    atoi(inputCmd,&y);
    if((x < 1900 || x > 2100)||(y > 12 || y < 1))
    {
    	printf("Input Error!");
        goto L1;
    }
        
    else
    {
    	PrintCalendar(x,y);
        
    }

}
void PrintCalendar(int year,int month){
	int c, d, e, f, i, j, k, l;
	e = 1;
	f = 0;
	l = 0;
	j = 1;
	d = 0;
	int a = year;
	int b = month;
	c = Zeller(a, b, 1);
	
	printf("\n%d year %dmonth calendar is:\n",a,b);
	
	for(int i=0;i<39;i++)
		printf("=");
	printf("\nSUN  MON  TUE  WED  THU  FRI  SAT\n");
	
	for(int i=0;i<39;i++)
		printf("=");
	/*
	cout << endl;
	cout << a << "年" << b << "月的日历为:" << endl;
	cout << setw(54) << setfill('=') << '=' << endl;
	cout << "星期日  星期一  星期二  星期三  星期四  星期五  星期六" << endl;
	cout << setw(54) << setfill('=') << '=' << endl;
	*/

	//判断这个月份有多少天
	switch (b) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			d = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			d = 30;
			break;
		case 2:
			if ((a % 4 == 0 && (a % 100 != 0)) || (a % 400 == 0))
				d = 29;
			else
				d = 28;
			break;
	}


	//输入第一行先导空格
	//printf("\n%d\n",c);
	printf("\n");
	while (l < c) {
		printf("     ");
		l = l + 1;
	}


	//输入第一行日期
	while (e <= (7 - c)) {
		printf("%d    ",e);
		//cout << e << "       ";
		e = e + 1;
	}
	printf("\n");


	//计算要输出几行完整的日期
	k = (d - (7 - c)) / 7;


	//输入日期
	while (j <= k) {
		i = e;
		while (e <= i + 6) {
			if (e <= 9)
				printf("%d    ",e);
				
			else
				printf("%d   ",e);
				
			e = e + 1;
		}
		printf("\n");
		j = j + 1;
	}


	//输入最后一行先导空格
	//printf("  ");


	//输入最后一行日期
	while (e <= d) {

		printf("%d   ",e);
		e = e + 1;
	}
	printf("\n");
	
}
void calendar(int fd_stdin,int fd_stdout){
	userInput(fd_stdin,fd_stdout);
}

